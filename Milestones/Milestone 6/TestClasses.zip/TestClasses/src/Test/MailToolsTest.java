package Test;

import org.junit.jupiter.api.Test;
import Main.MailTools;

import static org.junit.jupiter.api.Assertions.*;


public class MailToolsTest {

    @Test
    public void testValidateMailAddressRequiresNoAtSingEnsuresFalse() {
        // Arrange
        MailTools mailTools = new MailTools();

        // Act
        String email = "jondoe.nl";
        boolean result = mailTools.validateMailAddress(email);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testValidateMailAddressRequiresNoMailBoxPartEnsuresFalse() {
        // Arrange
        MailTools mailTools = new MailTools();

        // Act
        String email = "@hotmail.nl";
        boolean result = mailTools.validateMailAddress(email);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testValidateMailAddressRequiresSubdomainTLDDelimiterEnsuresFalse() {
        // Arrange
        MailTools mailTools = new MailTools();

        // Act
        String email = "sophie.jackson8@hotmail";
        boolean result = mailTools.validateMailAddress(email);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testValidateMailAddressRequiresNoSubdomainPartEnsuresFalse() {
        // Arrange
        MailTools mailTools = new MailTools();

        // Act
        String email = "maria778@.nl";
        boolean result = mailTools.validateMailAddress(email);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testValidateMailAddressRequiresNoTLDPartEnsuresFalse() {
        // Arrange
        MailTools mailTools = new MailTools();

        // Act
        String email = "info@bottle.";
        boolean result = mailTools.validateMailAddress(email);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testValidateMailAddressRequiresValidEmailEnsuresTrue() {
        // Arrange
        MailTools mailTools = new MailTools();

        // Act
        String email = "peter.harvey@gmail.com";
        boolean result = mailTools.validateMailAddress(email);

        // Assert
        assertTrue(result);
    }
}
