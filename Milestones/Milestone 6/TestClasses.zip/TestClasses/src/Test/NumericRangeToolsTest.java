package Test;

import Main.NumericRangeTools;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NumericRangeToolsTest {

    @Test
    public void testIsValidPercentageRequires50EnsuresTrue() {
        // Arrange
        NumericRangeTools numericRangeTools = new NumericRangeTools();

        // Act
        boolean result = numericRangeTools.isValidPercentage(50);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testIsValidPercentageRequiresNegativeNumberEnsuresFalse() {
        // Arrange
        NumericRangeTools numericRangeTools = new NumericRangeTools();

        // Act
        int number = -5;
        boolean result = numericRangeTools.isValidPercentage(number);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testIsValidPercentageRequiresNumberHigherThen100EnsuresFalse() {
        // Arrange
        NumericRangeTools numericRangeTools = new NumericRangeTools();

        // Act
        int number = 134;
        boolean result = numericRangeTools.isValidPercentage(number);

        // Assert
        assertFalse(result);
    }
}