package Test;

import org.junit.jupiter.api.Test;
import Main.DateTools;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DateToolsTest {

    /*
     * @desc Validates is a given date in the form of day, month and year is valid.
     *
     * @subcontract 31 days in month {
     * @requires (month = = 1 | | month = = 3 | | month = = 5 | | month = = 7 | |
     *month = = 8 | | month = = 10 | | month = = 12) && 1 <= day <= 31;
     * @ensures \result = true;
     * }
     */

    @Test
    public void testValidateDateRequiresDay31Month3EnsuresTrue() {
        //Arrange
        DateTools dateTools = new DateTools();

        // Act
        boolean result = dateTools.validateDate(31,3,1999);

        // Assert
        assertTrue(result);

    }

     /* @subcontract 30 days in month {
     * @requires (month = = 4 | | month = = 6 | | month = = 9 | | month = = 11) &&
     * 1 <= day <= 30;
     * @ensures \result = true;
     * }
     */

    @Test
    public void testValidateDateRequiresDay30Month4EnsuresTrue() {
        //Arrange
        DateTools dateTools = new DateTools();

        // Act
        boolean result = dateTools.validateDate(30,4,1999);

        // Assert
        assertTrue(result);

    }

     /* @subcontract 29 days in month {
     * @requires month == 2 && 1 <= day <= 29 &&
     * (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
     * @ensures \result = true;
     * }
     */

    @Test
    public void testValidateDateRequiresDay29Month2YearIsLeapYearEnsuresTrue() {
        //Arrange
        DateTools dateTools = new DateTools();

        // Act
        boolean result = dateTools.validateDate(29,2,2004);

        // Assert
        assertTrue(result);

    }

     /* @subcontract 28 days in month {
     * @requires month == 2 && 1 <= day <= 28 &&
     * (year % 4 != 0 || (year % 100 == 0 && year % 400 != 0));
     * @ensures \result = true;
     * }
     */

    @Test
    public void testValidateDateRequiresDay2Month2YearIsNotLeapYearEnsuresTrue() {
        //Arrange
        DateTools dateTools = new DateTools();

        // Act
        boolean result = dateTools.validateDate(28,2,2003);

        // Assert
        assertTrue(result);

    }

     /* @subcontract all other cases {
     * @requires no other accepting precondition;
     * @ensures \result = false;
     * }
     */

    @Test
    public void testValidateDateRequiresDay32EnsuresFalse() {
        //Arrange
        DateTools dateTools = new DateTools();

        // Act
        boolean result = dateTools.validateDate(32,2,2003);

        // Assert
        assertFalse(result);

    }
}