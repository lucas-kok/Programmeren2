package Main;

public class MailTools {

    /*
     * @desc Validates if mailAddress is valid. It should be in the form of:
     * <at least 1 character>@<at least 1 character>.<at least 1 character>
     * @subcontract no mailbox part {
     * @requires !mailAddress.contains("@") ||
     * mailAddress.split("@")[0].length < 1;
     * @ensures \result = false;
     * }
     * @subcontract subdomain-tld delimiter {
     * @requires !mailAddress.contains("@") ||
     * mailAddress.split("@")[1].split(".").length > 2;
     * @ensures \result = false;
     * }
     * @subcontract no subdomain part {
     * @requires !mailAddress.contains("@") ||
     * mailAddress.split("@")[1].split(".")[0].length < 1;
     * @ensures \result = false;
     * }
     * @subcontract no tld part {
     * @requires !mailAddress.contains("@") ||
     * mailAddress.split("@")[1].split(".")[1].length < 1;
     * @ensures \result = false;
     * }
     * @subcontract valid email {
     * @requires no other precondition
     * @ensures \result = true;
     * }
     */

    public static boolean validateMailAddress(String mailAddress) {
        if (!mailAddress.contains("@")) return false;

        String[] emailParts = mailAddress.split("@");
        if (emailParts.length != 2) return false;
        if (emailParts[0].isBlank() || emailParts[1].isBlank()) return false;

        if (emailParts[1].contains(".")) {
            String[] domainParts = emailParts[1].split("\\.");
            if (domainParts.length != 2) return false;
            return !domainParts[0].isBlank() && !domainParts[1].isBlank();
        } else {
            return false;
        }
    }
}


